const Superhero = require('../models/Superhero');

exports.createSuperhero = async (req, res) => {
    try {
        const hero = await Superhero.create(req.body);
        res.status(201).json(hero);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

exports.getSuperheroes = async (req, res) => {
    try {
        const heroes = await Superhero.find();
        res.status(200).json(heroes);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

exports.getSuperhero = async (req, res) => {
    try {
        const hero = await Superhero.findById(req.params.id);
        if (!hero) return res.status(404).json({ error: "Superhero not found" });
        res.status(200).json(hero);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

exports.updateSuperhero = async (req, res) => {
    try {
        const hero = await Superhero.findByIdAndUpdate(req.params.id, req.body, { new: true });
        if (!hero) return res.status(404).json({ error: "Superhero not found" });
        res.status(200).json(hero);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

exports.deleteSuperhero = async (req, res) => {
    try {
        const hero = await Superhero.findByIdAndDelete(req.params.id);
        if (!hero) return res.status(404).json({ error: "Superhero not found" });
        res.status(200).json({ message: "Superhero deleted" });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};
