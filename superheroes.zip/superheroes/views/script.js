document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('superheroForm');
    const list = document.getElementById('superheroList');

    // ✅ Registrar un nuevo superhéroe
    form.addEventListener('submit', async (event) => {
        event.preventDefault();

        const superhero = {
            realName: document.getElementById('realName').value,
            heroName: document.getElementById('heroName').value,
            photoUrl: document.getElementById('photoUrl').value,
            info: document.getElementById('info').value
        };

        const response = await fetch('/superheroes', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(superhero)
        });

        if (response.ok) {
            alert('Superhéroe registrado con éxito!');
            fetchSuperheroes();
            form.reset();
        } else {
            alert('Error al registrar el superhéroe.');
        }
    });

    // ✅ Obtener y mostrar superhéroes
    async function fetchSuperheroes() {
        const response = await fetch('/superheroes');
        const heroes = await response.json();
        list.innerHTML = heroes.map(hero => `
            <li>
                <h3>${hero.heroName} (${hero.realName})</h3>
                <img src="${hero.photoUrl}" width="100">
                <p>${hero.info}</p>
                <button onclick="deleteSuperhero('${hero._id}')">Eliminar</button>
            </li>
        `).join('');
    }

    // ✅ Eliminar un superhéroe
    async function deleteSuperhero(id) {
        const response = await fetch(`/superheroes/${id}`, { method: 'DELETE' });
        if (response.ok) {
            alert('Superhéroe eliminado.');
            fetchSuperheroes();
        } else {
            alert('Error al eliminar el superhéroe.');
        }
    }

    fetchSuperheroes();
});
