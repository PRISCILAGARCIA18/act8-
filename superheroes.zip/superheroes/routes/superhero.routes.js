const express = require('express');
const router = express.Router();
const superheroController = require('../controllers/superheroController');

router.post('/', superheroController.createSuperhero);
router.get('/', superheroController.getSuperheroes);
router.get('/:id', superheroController.getSuperhero);
router.put('/:id', superheroController.updateSuperhero);
router.delete('/:id', superheroController.deleteSuperhero);

module.exports = router;
