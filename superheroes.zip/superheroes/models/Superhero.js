const mongoose = require('mongoose');

const SuperheroSchema = new mongoose.Schema({
    realName: { type: String, required: true },
    heroName: { type: String, required: true },
    photoUrl: { type: String, required: true },
    info: { type: String, required: true }
});

module.exports = mongoose.model('Superhero', SuperheroSchema, 'superheros');


