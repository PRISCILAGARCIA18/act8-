const Subject = require('../models/subject.model');

exports.getSubjects = async (req, res) => {
    const subjects = await Subject.find();
    res.json(subjects);
};

exports.createSubject = async (req, res) => {
    const newSubject = new Subject(req.body);
    await newSubject.save();
    res.json({ message: "Materia agregada", subject: newSubject });
};
