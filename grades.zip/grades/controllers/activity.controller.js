const Activity = require('../models/activity.model');

exports.getActivities = async (req, res) => {
    try {
        if (req.params.subjectId) {
            // Si se proporciona un subjectId, obtener actividades solo de esa materia
            const activities = await Activity.find({ subject_id: req.params.subjectId });
            return res.json(activities);
        }
        // Si no hay subjectId, obtener todas las actividades
        const activities = await Activity.find();
        res.json(activities);
    } catch (error) {
        res.status(500).json({ message: "Error al obtener actividades", error });
    }
};

exports.createActivity = async (req, res) => {
    try {
        const newActivity = new Activity(req.body);
        await newActivity.save();
        res.json({ message: "Actividad agregada", activity: newActivity });
    } catch (error) {
        res.status(400).json({ message: "Error al crear actividad", error });
    }
};
