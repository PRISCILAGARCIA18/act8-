document.addEventListener("DOMContentLoaded", () => {
    loadSubjects(); // Cargar materias al iniciar

    document.getElementById("subjectForm").addEventListener("submit", async (event) => {
        event.preventDefault();
        const subjectName = document.getElementById("subjectName").value;

        if (!subjectName.trim()) return alert("Ingresa un nombre de materia válido");

        try {
            const response = await fetch("http://localhost:5000/subjects", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ name: subjectName })
            });

            const result = await response.json();
            alert(result.message);
            document.getElementById("subjectForm").reset();
            loadSubjects();
        } catch (error) {
            console.error("Error al registrar materia:", error);
        }
    });

    document.getElementById("activityForm").addEventListener("submit", async (event) => {
        event.preventDefault();
        const subjectId = document.getElementById("subjectSelect").value;
        const activityType = document.getElementById("activityType").value;
        const activityDate = document.getElementById("activityDate").value;
        const activityGrade = document.getElementById("activityGrade").value;

        if (!subjectId || !activityType || !activityDate) return alert("Completa todos los campos");

        try {
            const response = await fetch("http://localhost:5000/activities", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    subject_id: subjectId,
                    type: activityType,
                    date: activityDate,
                    grade: activityGrade ? parseFloat(activityGrade) : null
                })
            });

            const result = await response.json();
            alert(result.message);
            document.getElementById("activityForm").reset();
        } catch (error) {
            console.error("Error al registrar actividad:", error);
        }
    });
});

// Cargar materias en la lista y en el select de actividades
async function loadSubjects() {
    try {
        const response = await fetch("http://localhost:5000/subjects");
        const subjects = await response.json();

        console.log("Materias cargadas:", subjects);

        const subjectList = document.getElementById("subjectList");
        subjectList.innerHTML = "";

        const subjectSelect = document.getElementById("subjectSelect");
        subjectSelect.innerHTML = '<option value="">Selecciona una materia</option>';

        subjects.forEach(subject => {
            const li = document.createElement("li");
            li.innerHTML = `<strong>${subject.name}</strong> - ID: <span class="id">${subject._id}</span>`;
            subjectList.appendChild(li);

            const option = document.createElement("option");
            option.value = subject._id;
            option.textContent = subject.name;
            subjectSelect.appendChild(option);
        });

    } catch (error) {
        console.error("Error al cargar materias:", error);
    }
}
