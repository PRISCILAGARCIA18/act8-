const mongoose = require('mongoose');

const ActivitySchema = new mongoose.Schema({
    subject_id: { type: mongoose.Schema.Types.ObjectId, ref: 'Subject', required: true },
    type: { type: String, required: true }, // Ejemplo: "Tarea", "Examen"
    date: { type: Date, required: true },
    grade: { type: Number, min: 0, max: 10 }
});

module.exports = mongoose.model('Activity', ActivitySchema);
